package com.googleSheet.pickDataFromExcel;

import java.io.FileInputStream;
import java.io.IOException;
import java.security.GeneralSecurityException;
import java.util.List;

import org.apache.commons.compress.utils.Lists;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

import com.google.api.services.sheets.v4.Sheets;
import com.google.api.services.sheets.v4.model.UpdateValuesResponse;
import com.google.api.services.sheets.v4.model.ValueRange;
import com.googleSheet.pickDataFromExcel.config.ConfigurationProperties;
import com.googleSheet.pickDataFromExcel.googleService.SheetsServiceUtil;

/**
 * Hello world!
 *
 */
public class PickDataFromExcel {
	public static void main(String[] args) {
		System.out.println("Code is Started!!");

		List<List<Object>> excelData = readExcel(ConfigurationProperties.excelFileReadPath);

		// Write Data into Google Sheets
		try {
			writeGoogleSheets(excelData);
			System.out.println("/nData is updated Succesfully !!!");
		} catch (IOException | GeneralSecurityException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	private static List<List<Object>> readExcel(String filePath) {
		try {
			FileInputStream file = new FileInputStream(filePath);
			Workbook workbook = WorkbookFactory.create(file);
			Sheet sheet = workbook.getSheetAt(0); // assuming you want to read the first sheet

			List<List<Object>> data = Lists.newArrayList();

			for (Row row : sheet) {
				List<Object> rowData = Lists.newArrayList();
				for (Cell cell : row) {
					rowData.add(cell.toString());
				}
				data.add(rowData);
			}

			workbook.close();
			return data;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	private static void writeGoogleSheets(List<List<Object>> data) throws IOException, GeneralSecurityException {
		// Use the credentials file you obtained from Google Sheets API
		// Set up Sheets service
		Sheets sheetsService = SheetsServiceUtil.getSheetsService();
		// Create a ValueRange object with the data
		ValueRange body = new ValueRange().setValues(data);

		// Update the spreadsheet
		UpdateValuesResponse result = sheetsService.spreadsheets().values()
				.update("1rEv4gQJb2-VS96rt6-d-gR0iqkgI102LpwjbpQoZaHY", "A1:E40", body).setValueInputOption("RAW")
				.execute();

		System.out.printf("%d cells updated.", result.getUpdatedCells());
	}

}