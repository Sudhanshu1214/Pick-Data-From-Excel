package com.googleSheet.pickDataFromExcel.config;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import com.googleSheet.pickDataFromExcel.constant.Constant;

public class ConfigurationProperties {

	public static String excelFileReadPath;

	static {
		String resource = getNamePropertyFile();
		InputStream in = ConfigurationProperties.class.getResourceAsStream(resource);
		Properties properties = new Properties();
		try {
			properties.load(in);
		} catch (IOException e) {

			e.printStackTrace();
		}

		excelFileReadPath = properties.getProperty(Constant.EXCEL_READ_FILE_PATH);
		System.out.println("excelFileReadPath is : " + excelFileReadPath);
	}

	private static String getNamePropertyFile() {
		return "/configuration.properties";

	}
}
