package com.googleSheet.pickDataFromExcel.googleService;

import java.io.IOException;
import java.security.GeneralSecurityException;

import com.google.api.client.googleapis.javanet.GoogleNetHttpTransport;
import com.google.api.client.json.jackson2.JacksonFactory;
import com.google.api.services.sheets.v4.Sheets;
import com.google.auth.http.HttpCredentialsAdapter;
import com.google.auth.oauth2.GoogleCredentials;
import com.googleSheet.pickDataFromExcel.constant.Constant;

public class SheetsServiceUtil {

	private static final String APPLICATION_NAME = Constant.GOOGLE_EXCEL_SHEET_NAME;

	public static Sheets getSheetsService() throws IOException, GeneralSecurityException {
		GoogleCredentials credential = GoogleAuthorizeUtil.authorize();

		Sheets service = new Sheets.Builder(GoogleNetHttpTransport.newTrustedTransport(),
				JacksonFactory.getDefaultInstance(), new HttpCredentialsAdapter(credential))
				.setApplicationName(APPLICATION_NAME).build();
		return service;
	}
}