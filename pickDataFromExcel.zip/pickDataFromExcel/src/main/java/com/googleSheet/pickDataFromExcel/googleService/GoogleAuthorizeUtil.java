package com.googleSheet.pickDataFromExcel.googleService;

import java.io.IOException;
import java.io.InputStream;
import java.security.GeneralSecurityException;
import java.util.Arrays;
import java.util.List;

import com.google.api.services.sheets.v4.SheetsScopes;
import com.google.auth.oauth2.GoogleCredentials;



public class GoogleAuthorizeUtil {
	
	public static GoogleCredentials authorize() throws IOException, GeneralSecurityException {

		// build GoogleClientSecrets from JSON file
		InputStream in = GoogleAuthorizeUtil.class.getResourceAsStream("/sidGoogle-credential.json");
		System.out.println("in : " + in);
//        GoogleClientSecrets clientSecrets = GoogleClientSecrets.load(JacksonFactory.getDefaultInstance(), new InputStreamReader(in));

		List<String> scopes = Arrays.asList(SheetsScopes.SPREADSHEETS, SheetsScopes.DRIVE);

		// build Credential object
//        GoogleAuthorizationCodeFlow flow = new GoogleAuthorizationCodeFlow.Builder(GoogleNetHttpTransport.newTrustedTransport(), JacksonFactory.getDefaultInstance(), clientSecrets, scopes).setDataStoreFactory(new MemoryDataStoreFactory())
//                .setAccessType("offline").build();
//        Credential credential = new AuthorizationCodeInstalledApp(flow, new LocalServerReceiver()).authorize("user");

		GoogleCredentials googleCredentials = GoogleCredentials.fromStream(in).createScoped(scopes);

		System.out.println("googleCredentials : " + googleCredentials);

		return googleCredentials;
	}

}
