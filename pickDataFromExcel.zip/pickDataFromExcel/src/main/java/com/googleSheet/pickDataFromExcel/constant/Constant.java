package com.googleSheet.pickDataFromExcel.constant;

public class Constant {

	public static String EXCEL_READ_FILE_PATH = "excel.file.path";
	public static String GOOGLE_EXCEL_SHEET_NAME = "excel.sheet.name";

}
